package com.lina.life;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
